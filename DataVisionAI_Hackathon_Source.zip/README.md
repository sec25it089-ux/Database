# DataVision AI

DataVision AI is a conversational database analytics assistant built for the Sairam Hackathon 2026 challenge.

## What makes it different

Instead of only converting text to SQL, DataVision AI follows a small agent pipeline:

1. Understand the user's question.
2. Inspect the database schema.
3. Generate a safe read-only SQL query.
4. Validate the SQL before execution.
5. Execute the query.
6. Automatically choose a useful visualization.
7. Explain the result in plain English.
8. Keep the conversation context inside the session.

The app works in **demo mode without an API key**, so judges can run it immediately. If `OPENAI_API_KEY` is supplied, the optional LLM layer can be added through the service in `app/agent.py`.

## Problem

Non-technical users often have useful questions about business data but cannot write SQL or understand database schemas. The hackathon asks teams to build a ChatGPT-like interface that connects natural-language questions to databases, visualizations, and explanations.

## Solution

A user can ask:

- "Show the top 5 products by revenue."
- "What is the monthly sales trend?"
- "Which customers placed the most orders?"
- "Show me the database relationships."

DataVision AI returns a table, chart, and explanation.

## Required hackathon tools implemented

| Tool | Implementation |
|---|---|
| `get_schema` | `app/db.py` |
| `execute_query` | `app/db.py` with read-only validation |
| `generate_chart` | `app/visualizer.py` |
| `generate_flowchart` | Mermaid ER/process diagram generation |
| `explain_data` | `app/agent.py` |

## Architecture

```text
Browser
  |
  v
FastAPI
  |
  +--> Agent / Intent Router
  |       |
  |       +--> Schema Tool
  |       +--> SQL Generator
  |       +--> SQL Safety Validator
  |       +--> Query Executor
  |       +--> Chart Generator
  |       +--> Explanation Engine
  |
  v
SQLite demo database
```

## Setup

### 1. Create a virtual environment

Windows:

```bash
python -m venv .venv
.venv\Scripts\activate
```

Linux/macOS:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Create the demo database

```bash
python seed.py
```

### 4. Configure environment

Copy `.env.example` to `.env`.

An API key is optional for the included demo.

### 5. Start the application

```bash
uvicorn app.main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

## Demo questions

Try these:

- `Show the top 5 products by revenue`
- `Show monthly revenue trend`
- `Which customers have the most orders?`
- `Show revenue by category`
- `Draw the ER diagram`
- `How many orders are there?`

## Security design

The query executor rejects mutating SQL such as `INSERT`, `UPDATE`, `DELETE`, `DROP`, `ALTER`, and `CREATE`. Only read-oriented queries are accepted in the demo.

Never put API keys directly into source code. Use `.env`.

## Hackathon submission checklist

- Source code in GitHub
- README.md
- Setup instructions
- Architecture diagram
- Demo video
- Live/local demo
- `.env.example` without secrets
- Team information

The challenge document specifically asks for source code, README, demo video, and a working live/local demo. It also recommends clean code, `.env` configuration, Docker support, and unit tests.

## Future extensions

- PostgreSQL/MySQL connector
- Voice input
- CSV export
- Query history and favorites
- Custom dashboard builder
- Multiple databases
- Role-based access control
- LLM-generated SQL with human-readable SQL preview
