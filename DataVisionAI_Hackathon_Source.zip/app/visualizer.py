import pandas as pd
import plotly.express as px

def choose_chart(data):
    rows = data["rows"]
    columns = data["columns"]
    if not rows or len(columns) < 2:
        return None

    df = pd.DataFrame(rows)
    numeric = [c for c in columns if pd.api.types.is_numeric_dtype(df[c])]
    non_numeric = [c for c in columns if c not in numeric]

    if not numeric:
        return None

    y = numeric[-1]
    x = non_numeric[0] if non_numeric else columns[0]

    if non_numeric:
        if "date" in x.lower() or "month" in x.lower() or "year" in x.lower():
            fig = px.line(df, x=x, y=y, markers=True, title=f"{y} over {x}")
        elif len(df) <= 8:
            fig = px.pie(df, names=x, values=y, title=f"{y} distribution")
        else:
            fig = px.bar(df, x=x, y=y, title=f"{y} by {x}")
    else:
        fig = px.bar(df, x=x, y=y, title=f"{y} by {x}")

    fig.update_layout(margin=dict(l=20, r=20, t=55, b=20))
    return fig.to_json()
