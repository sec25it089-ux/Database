from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from .agent import answer
from .db import get_schema
from .visualizer import choose_chart

app = FastAPI(title="DataVision AI")
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/api/schema")
def schema():
    return get_schema()

@app.post("/api/chat")
async def chat(payload: dict):
    question = str(payload.get("message", "")).strip()
    if not question:
        return JSONResponse({"error": "Message is required."}, status_code=400)

    result = answer(question)

    if result["type"] == "data":
        result["chart"] = choose_chart(result["result"])

    return result
