import os
import re
import sqlite3
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()
DB_PATH = os.getenv("DATABASE_PATH", "data/demo.db")

BLOCKED = re.compile(
    r"\b(INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|REPLACE|TRUNCATE|ATTACH|DETACH|PRAGMA)\b",
    re.I,
)

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def get_schema():
    conn = get_connection()
    tables = {}
    rows = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    ).fetchall()
    for row in rows:
        name = row["name"]
        cols = conn.execute(f'PRAGMA table_info("{name}")').fetchall()
        tables[name] = [
            {"name": c["name"], "type": c["type"], "pk": bool(c["pk"])}
            for c in cols
        ]
    conn.close()
    return tables

def validate_read_only(sql: str):
    cleaned = sql.strip().rstrip(";")
    if not cleaned.lower().startswith(("select", "with")):
        raise ValueError("Only SELECT/WITH queries are allowed.")
    if BLOCKED.search(cleaned):
        raise ValueError("Unsafe SQL operation rejected.")
    if ";" in cleaned:
        raise ValueError("Multiple SQL statements are not allowed.")
    return cleaned

def execute_query(sql: str):
    sql = validate_read_only(sql)
    conn = get_connection()
    try:
        rows = conn.execute(sql).fetchall()
        columns = [d[0] for d in conn.execute(sql).description]
        return {"columns": columns, "rows": [dict(r) for r in rows]}
    finally:
        conn.close()
