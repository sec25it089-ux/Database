import re
from .db import get_schema, execute_query

def normalize(q):
    return re.sub(r"\s+", " ", q.lower().strip())

def generate_sql(question):
    q = normalize(question)

    if "top" in q and "product" in q and ("revenue" in q or "sales" in q):
        limit = 5
        m = re.search(r"top\s+(\d+)", q)
        if m:
            limit = min(int(m.group(1)), 20)
        return f"""
SELECT p.name AS product,
       ROUND(SUM(oi.quantity * oi.unit_price), 2) AS revenue
FROM order_items oi
JOIN products p ON p.product_id = oi.product_id
JOIN orders o ON o.order_id = oi.order_id
WHERE o.status <> 'Cancelled'
GROUP BY p.product_id, p.name
ORDER BY revenue DESC
LIMIT {limit}
"""

    if "monthly" in q and ("revenue" in q or "sales" in q or "trend" in q):
        return """
SELECT substr(o.order_date, 1, 7) AS month,
       ROUND(SUM(oi.quantity * oi.unit_price), 2) AS revenue
FROM orders o
JOIN order_items oi ON oi.order_id = o.order_id
WHERE o.status <> 'Cancelled'
GROUP BY month
ORDER BY month
"""

    if "customer" in q and ("most orders" in q or "orders" in q):
        return """
SELECT c.name AS customer,
       COUNT(o.order_id) AS orders
FROM customers c
JOIN orders o ON o.customer_id = c.customer_id
GROUP BY c.customer_id, c.name
ORDER BY orders DESC
LIMIT 10
"""

    if "category" in q and ("revenue" in q or "sales" in q):
        return """
SELECT p.category,
       ROUND(SUM(oi.quantity * oi.unit_price), 2) AS revenue
FROM order_items oi
JOIN products p ON p.product_id = oi.product_id
JOIN orders o ON o.order_id = oi.order_id
WHERE o.status <> 'Cancelled'
GROUP BY p.category
ORDER BY revenue DESC
"""

    if "how many" in q and "order" in q:
        return "SELECT COUNT(*) AS total_orders FROM orders"

    if "how many" in q and "customer" in q:
        return "SELECT COUNT(*) AS total_customers FROM customers"

    if "how many" in q and "product" in q:
        return "SELECT COUNT(*) AS total_products FROM products"

    if "average" in q and "order" in q:
        return """
SELECT ROUND(AVG(order_total), 2) AS average_order_value
FROM (
    SELECT o.order_id, SUM(oi.quantity * oi.unit_price) AS order_total
    FROM orders o
    JOIN order_items oi ON oi.order_id = o.order_id
    WHERE o.status <> 'Cancelled'
    GROUP BY o.order_id
)
"""

    return None

def explain_data(question, result):
    rows = result["rows"]
    if not rows:
        return "The query ran successfully, but no matching records were found."

    if len(rows) == 1 and len(result["columns"]) == 1:
        value = next(iter(rows[0].values()))
        return f"The result is {value}."

    numeric_cols = []
    for col in result["columns"]:
        if isinstance(rows[0].get(col), (int, float)):
            numeric_cols.append(col)

    if numeric_cols:
        metric = numeric_cols[-1]
        top = max(rows, key=lambda r: (r.get(metric) if isinstance(r.get(metric), (int,float)) else float("-inf")))
        label = next((v for k, v in top.items() if k != metric), "the leading category")
        return f"The highest value is {top[metric]:,.2f} for {label}. The table contains {len(rows)} result rows."

    return f"The database returned {len(rows)} matching rows."

def answer(question):
    if "er diagram" in normalize(question) or "schema" in normalize(question) and "show" in normalize(question):
        return {"type": "diagram", "schema": get_schema()}

    sql = generate_sql(question)
    if not sql:
        return {
            "type": "help",
            "message": "Try: 'top 5 products by revenue', 'monthly revenue trend', 'customers with the most orders', 'revenue by category', or 'how many orders?'"
        }

    result = execute_query(sql)
    return {
        "type": "data",
        "sql": sql.strip(),
        "result": result,
        "explanation": explain_data(question, result),
    }
