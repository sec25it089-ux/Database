import sqlite3
from pathlib import Path
from random import choice, randint, uniform
from datetime import date, timedelta

DB = Path("data/demo.db")
DB.parent.mkdir(exist_ok=True)

conn = sqlite3.connect(DB)
cur = conn.cursor()

cur.executescript("""
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS customers;

CREATE TABLE customers (
    customer_id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    city TEXT NOT NULL,
    segment TEXT NOT NULL
);

CREATE TABLE products (
    product_id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    price REAL NOT NULL
);

CREATE TABLE orders (
    order_id INTEGER PRIMARY KEY,
    customer_id INTEGER NOT NULL,
    order_date TEXT NOT NULL,
    status TEXT NOT NULL,
    FOREIGN KEY(customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE order_items (
    item_id INTEGER PRIMARY KEY,
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    unit_price REAL NOT NULL,
    FOREIGN KEY(order_id) REFERENCES orders(order_id),
    FOREIGN KEY(product_id) REFERENCES products(product_id)
);
""")

customers = [
    (1, "Ananya", "Chennai", "Student"),
    (2, "Arjun", "Bengaluru", "Professional"),
    (3, "Meera", "Hyderabad", "Professional"),
    (4, "Rahul", "Chennai", "Business"),
    (5, "Kavya", "Coimbatore", "Student"),
    (6, "Vikram", "Madurai", "Business"),
    (7, "Nisha", "Bengaluru", "Professional"),
    (8, "Rohan", "Chennai", "Professional"),
]
cur.executemany("INSERT INTO customers VALUES (?, ?, ?, ?)", customers)

products = [
    (1, "Smart Watch", "Wearables", 4999),
    (2, "Wireless Earbuds", "Audio", 2499),
    (3, "Laptop Stand", "Accessories", 1799),
    (4, "Mechanical Keyboard", "Accessories", 3999),
    (5, "USB-C Hub", "Accessories", 2299),
    (6, "Bluetooth Speaker", "Audio", 3299),
]
cur.executemany("INSERT INTO products VALUES (?, ?, ?, ?)", products)

start = date(2026, 1, 1)
order_rows, item_rows = [], []
item_id = 1

for order_id in range(1, 81):
    customer_id = choice(customers)[0]
    d = start + timedelta(days=randint(0, 210))
    status = choice(["Delivered", "Delivered", "Delivered", "Shipped", "Cancelled"])
    order_rows.append((order_id, customer_id, d.isoformat(), status))
    for _ in range(randint(1, 3)):
        product_id = choice(products)[0]
        price = next(p[3] for p in products if p[0] == product_id)
        qty = randint(1, 4)
        item_rows.append((item_id, order_id, product_id, qty, price))
        item_id += 1

cur.executemany("INSERT INTO orders VALUES (?, ?, ?, ?)", order_rows)
cur.executemany("INSERT INTO order_items VALUES (?, ?, ?, ?, ?)", item_rows)

conn.commit()
conn.close()
print(f"Created {DB}")
