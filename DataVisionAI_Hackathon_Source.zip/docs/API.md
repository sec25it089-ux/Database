# API

## GET `/api/schema`

Returns database tables and columns.

## POST `/api/chat`

Request:

```json
{
  "message": "Show the top 5 products by revenue"
}
```

Analytics response contains:
- `sql`
- `result.columns`
- `result.rows`
- `explanation`
- `chart`

The response can also contain:
- `type=help`
- `type=diagram`
