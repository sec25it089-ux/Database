# Architecture

## Agent pipeline

```text
Natural language
      |
      v
Intent router
      |
      +---- schema/diagram request ---> Schema Tool ---> Mermaid-ready data
      |
      +---- analytics request --------> SQL Generator
                                           |
                                           v
                                     SQL Safety Guard
                                           |
                                           v
                                      Query Tool
                                           |
                               +-----------+-----------+
                               |                       |
                               v                       v
                         Chart Generator        Explanation Engine
                               |                       |
                               +-----------+-----------+
                                           |
                                           v
                                      Chat response
```

## Why this is useful

The architecture separates tools from the interface. A PostgreSQL connector, an LLM SQL generator, or a dashboard module can be added without rewriting the UI.

## Hackathon alignment

The challenge asks for schema discovery, query execution, chart generation, flowcharts/ER diagrams, and conversational explanations. This project maps those requirements to separate services and keeps the query executor protected by a read-only SQL validator.
