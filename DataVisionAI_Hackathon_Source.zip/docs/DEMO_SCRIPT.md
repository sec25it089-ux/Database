# 3–5 Minute Demo Script

## 0:00–0:30 — Problem

"Business data is locked behind SQL and database schemas. Non-technical users know what they want to ask but not how to query it."

## 0:30–1:00 — Solution

"This is DataVision AI. Users ask questions in normal language. The system converts the intent into a database operation, validates it, retrieves data, visualizes it, and explains the result."

## 1:00–2:00 — Analytics demo

Ask:

`Show the top 5 products by revenue`

Point out:
- generated SQL
- result table
- automatically selected visualization
- natural-language insight

## 2:00–2:40 — Trend demo

Ask:

`Show monthly revenue trend`

Explain that the system recognizes a time dimension and chooses a line chart.

## 2:40–3:20 — Database understanding

Ask:

`Draw the ER diagram`

Show the detected database tables and relationships.

## 3:20–4:00 — Safety and engineering

Show the SQL validator and explain:
- only SELECT/WITH is accepted
- mutating operations are rejected
- API keys are kept in `.env`
- tools are modular

## 4:00–5:00 — Future vision

Mention PostgreSQL/MySQL, voice input, CSV export, multiple databases, dashboards, query history, and a stronger LLM planner.
